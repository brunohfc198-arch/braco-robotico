package com.example.bracocontrole

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null
    private lateinit var status: TextView
    private lateinit var deviceList: Spinner
    private var devices = listOf<android.bluetooth.BluetoothDevice>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 10)
        }
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 10)
            setBackgroundColor(Color.rgb(10, 15, 27))
        }

        val title = TextView(this).apply {
            text = "ROBOT // CONTROL"
            textSize = 22f
            setTextColor(Color.rgb(90, 245, 190))
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
            letterSpacing = 0.12f
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 42))

        status = TextView(this).apply {
            text = "● DESCONECTADO"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 190, 75))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 27))

        val connection = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        deviceList = Spinner(this)
        connection.addView(deviceList, LinearLayout.LayoutParams(0, 46, 1f))
        connection.addView(Button(this).apply {
            text = "BUSCAR"
            setOnClickListener { loadDevices() }
        })
        connection.addView(Button(this).apply {
            text = "CONECTAR"
            setOnClickListener { connectDevice() }
        })
        root.addView(connection)

        val section = TextView(this).apply {
            text = "MOVIMENTOS"
            textSize = 12f
            setTextColor(Color.rgb(90, 245, 190))
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        }
        root.addView(section, LinearLayout.LayoutParams(-1, 30))

        // Gamepad-style directional cluster
        val padArea = FrameLayout(this)
        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER }
        top.addView(gameButton("▲", "B3", true), LinearLayout.LayoutParams(82, 58).apply { bottomMargin = 5 })
        pad.addView(top)
        val middle = LinearLayout(this).apply { gravity = Gravity.CENTER }
        middle.addView(gameButton("◀", "B5", true), LinearLayout.LayoutParams(82, 58).apply { rightMargin = 5 })
        middle.addView(TextView(this).apply {
            text = "D-PAD"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        }, LinearLayout.LayoutParams(65, 58))
        middle.addView(gameButton("▶", "B6", true), LinearLayout.LayoutParams(82, 58).apply { leftMargin = 5 })
        pad.addView(middle)
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottom.addView(gameButton("▼", "B4", true), LinearLayout.LayoutParams(82, 58).apply { topMargin = 5 })
        pad.addView(bottom)
        padArea.addView(pad, FrameLayout.LayoutParams(-1, -1))
        root.addView(padArea, LinearLayout.LayoutParams(-1, 205))

        val actionsTitle = TextView(this).apply {
            text = "AÇÕES DO BRAÇO"
            textSize = 12f
            setTextColor(Color.rgb(90, 245, 190))
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        }
        root.addView(actionsTitle, LinearLayout.LayoutParams(-1, 27))

        val grid = GridLayout(this).apply {
            columnCount = 3
            rowCount = 2
            useDefaultMargins = true
        }
        val actions = listOf(
            "A\nABRIR GARRA" to "B1",
            "B\nFECHAR GARRA" to "B2",
            "X\nGIRAR BASE" to "B7",
            "Y\nCENTRALIZAR" to "B8",
            "L\nBRAÇO" to "B9",
            "R\nPULSO" to "B10"
        )
        actions.forEach { (label, command) ->
            grid.addView(gameButton(label, command, false), GridLayout.LayoutParams().apply {
                width = 0
                height = 76
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(5, 5, 5, 5)
            })
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "TOQUE NOS BOTÕES PARA ENVIAR COMANDOS • HC-06"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
        }
        root.addView(footer, LinearLayout.LayoutParams(-1, 25))
        setContentView(root)
        loadDevices()
    }

    private fun gameButton(label: String, command: String, directional: Boolean): Button {
        return Button(this).apply {
            text = label
            textSize = if (directional) 22f else 13f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(if (directional) Color.rgb(35, 49, 70) else Color.rgb(25, 75, 77))
                cornerRadius = 18f
                setStroke(2, if (directional) Color.rgb(90, 245, 190) else Color.rgb(50, 210, 175))
            }
            setOnClickListener { send("$command\n") }
        }
    }

    private fun loadDevices() {
        try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null) { status.text = "Bluetooth indisponível"; return }
            devices = adapter.bondedDevices?.toList() ?: emptyList()
            deviceList.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                devices.map { "${it.name ?: "Dispositivo"} (${it.address})" })
            status.text = "● ESCOLHA O HC-06 PAREADO"
        } catch (_: SecurityException) { status.text = "Permita acesso a dispositivos próximos" }
    }

    private fun connectDevice() {
        if (devices.isEmpty()) { status.text = "Pareie o HC-06 nas configurações Bluetooth primeiro"; return }
        val d = devices.getOrNull(deviceList.selectedItemPosition) ?: return
        status.text = "● CONECTANDO..."
        thread {
            try {
                BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                val s = d.createRfcommSocketToServiceRecord(spp)
                s.connect()
                socket = s
                output = s.outputStream
                runOnUiThread {
                    status.text = "● CONECTADO: ${d.name}"
                    status.setTextColor(Color.rgb(90, 245, 190))
                }
            } catch (_: Exception) {
                runOnUiThread {
                    status.text = "● FALHA NA CONEXÃO"
                    status.setTextColor(Color.RED)
                }
            }
        }
    }

    @Synchronized private fun send(command: String) {
        try {
            output?.write(command.toByteArray(Charsets.US_ASCII))
            if (output == null) runOnUiThread { status.text = "● CONECTE O HC-06 PRIMEIRO" }
        } catch (_: Exception) {
            runOnUiThread { status.text = "● CONEXÃO PERDIDA"; status.setTextColor(Color.RED) }
        }
    }

    override fun onDestroy() {
        try { output?.close(); socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
